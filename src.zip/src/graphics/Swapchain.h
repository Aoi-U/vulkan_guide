// class to manage vulkan swapchains
#include <graphics/utils/vk_types.h>

class Swapchain 
{
public:
	void init(VkPhysicalDevice chosenGPU, VkDevice device, VkSurfaceKHR surface, uint32_t width, uint32_t height);

	void cleanup(VkDevice device);
	
	void destroy_swapchain();

	void create_swapchain(uint32_t width, uint32_t height);

	// getters
	VkSwapchainKHR get() const { return _swapchain; }
	const std::vector<VkImage>& get_images() const { return _swapchainImages; }
	const std::vector<VkImageView>& get_image_views() const { return _swapchainImageViews; }
	const std::vector<VkSemaphore>& get_render_semaphores() const { return _renderSemaphores; }
	VkFormat get_image_format() const { return _swapchainImageFormat; }
	VkExtent2D get_extent() const { return _swapchainExtent; }

private:
	// vulkan handles
	VkPhysicalDevice _chosenGPU{ VK_NULL_HANDLE };
	VkDevice _device{ VK_NULL_HANDLE };
	VkSurfaceKHR _surface{ VK_NULL_HANDLE };

	// swapchain handles
	VkSwapchainKHR _swapchain{ VK_NULL_HANDLE };
	VkFormat _swapchainImageFormat{ VK_FORMAT_UNDEFINED };
	std::vector<VkImage> _swapchainImages;
	std::vector<VkImageView> _swapchainImageViews;
	std::vector<VkSemaphore> _renderSemaphores;
	VkExtent2D _swapchainExtent{ 0, 0 };

};