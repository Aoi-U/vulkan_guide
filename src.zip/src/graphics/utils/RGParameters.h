#pragma once

#include <cstdint>
#include <vulkan/vulkan.h>

struct RGTextureHandle
{
	uint32_t index{ UINT32_MAX };
	bool is_valid() const { return index != UINT32_MAX; };
	bool operator==(const RGTextureHandle& other) const { return index == other.index; }
};

struct RGBufferHandle
{
	uint32_t index{ UINT32_MAX };
	bool is_valid() const { return index != UINT32_MAX; }
	bool operator==(const RGBufferHandle& other) const { return index == other.index; }
};

enum class RGResourceUsage : uint32_t
{
	None = 0,
	ShaderRead = 1 << 0,
	StorageRead = 1 << 1,
	StorageWrite = 1 << 2,
	ColorAttachment = 1 << 3,
	DepthAttachment = 1 << 4,
	IndirectArgs = 1 << 5,
	TransferSrc = 1 << 6,
	TransferDst = 1 << 7,
	Present = 1 << 8
};

inline RGResourceUsage operator|(RGResourceUsage a, RGResourceUsage b)
{
	return static_cast<RGResourceUsage>(static_cast<uint32_t>(a) | static_cast<uint32_t>(b));
}

inline bool operator&(RGResourceUsage a, RGResourceUsage b)
{
	return (static_cast<uint32_t>(a) & static_cast<uint32_t>(b)) != 0;
}

// https://dev.epicgames.com/documentation/unreal-engine/render-dependency-graph-in-unreal-engine

struct FrustumCullPassParameters
{
	RGBufferHandle gpuObjectBuffer;
	RGBufferHandle gpuInstanceBuffer;
	RGBufferHandle gpuIndirectBuffer;
	RGBufferHandle gpuCountBuffer;
	RGBufferHandle cullStatsBuffer;

	RGBufferHandle gpuShadowIndirectBuffer;
	RGBufferHandle gpuShadowInstanceBuffer;
};

struct GeometryPassParameters
{
	// inputs
	RGBufferHandle gpuObjectBuffer;
	RGBufferHandle gpuInstanceBuffer;
	RGBufferHandle gpuIndirectBuffer;
	RGBufferHandle gpuCountBuffer;
	RGBufferHandle materialBuffer;

	// outputs
	RGTextureHandle gPosition;
	RGTextureHandle gNormal;
	RGTextureHandle gAlbedo;
	RGTextureHandle gMetalRough;
	RGTextureHandle gEmissive;
	RGTextureHandle depth;
};

struct ShadowPassParameters
{
	// inputs
	RGBufferHandle gpuObjectBuffer;
	RGBufferHandle gpuInstanceBuffer;
	RGBufferHandle gpuIndirectBuffer;
	RGBufferHandle gpuCountBuffer;

	// outputs
	RGTextureHandle shadowMap;
};

struct PointShadowPassParameters
{
	// inputs
	RGBufferHandle gpuObjectBuffer;
	RGBufferHandle gpuInstanceBuffer;
	RGBufferHandle gpuIndirectBuffer;
	RGBufferHandle gpuCountBuffer;

	// outputs
	RGTextureHandle pointShadowMap;
};


struct SSAOPassParameters
{
	// inputs
	RGTextureHandle gPosition;
	RGTextureHandle gNormal;

	// outputs
	RGTextureHandle ssao;
};

struct SSAOBlurPassParameters
{
	// inputs
	RGTextureHandle ssao;

	// outputs
	RGTextureHandle ssaoBlur;
};

struct DeferredPassParameters
{
	// inputs
	RGTextureHandle gPosition;
	RGTextureHandle gNormal;
	RGTextureHandle gAlbedo;
	RGTextureHandle gMetalRough;
	RGTextureHandle gEmissive;
	RGTextureHandle depth;
	RGTextureHandle shadowMap;
	RGTextureHandle pointShadowMap;
	RGTextureHandle ssao;

	// outputs
	RGTextureHandle sceneColor;
};


struct SkyboxPassParameters
{
	// outputs
	RGTextureHandle sceneColor;
	RGTextureHandle sceneDepth;
};

struct BloomDownsampleParams
{
	RGTextureHandle src;
	RGTextureHandle dst;
	glm::vec2 srcTexelSize;
	int mipLevel;
};

struct BloomUpsampleParams
{
	RGTextureHandle src;
	RGTextureHandle dst;
};

struct PostProcessPassParameters
{
	// input
	RGTextureHandle bloomColor;
	RGTextureHandle sceneColor;

	// output
	RGTextureHandle finalColor;
};